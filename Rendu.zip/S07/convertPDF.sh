#!/bin/bash
pandoc -s --toc --toc-depth=2 -o Rendu.pdf Rendu.md annexes.md